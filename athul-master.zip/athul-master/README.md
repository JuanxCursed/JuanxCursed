<h2 align="center">👋 Hello! I'm Athul.</h2>
<p align="center">
  <a href="https://blog.athulcyriac.xyz">Blog</a> •
  <a href="https://twitter.com/athulcajay">Twitter</a>
</p>


- 🔭 I’m currently working on **A Platform for Hackathons in Kerala**
- 🌱 I’m currently learning **Go and Algorithms**
- 💬 Ask me about **Go, Git and Python**
- 📫 How to reach me: [@athulcajay](https://twitter.com/athulcajay) on Twitter
- ⚡ Fun fact: Big Fan of the :zap: emoji

-------

**📝 Latest Blog Posts**

<!-- BLOG-POST-LIST:START -->
- [Of Wires and Solder](https://blog.athulcyriac.xyz/blog/macropad/)
- [Coming Back to Pink Floyd](https://blog.athulcyriac.xyz/blog/pink-floyd/)
- [The Intern](https://blog.athulcyriac.xyz/blog/frappe-internship/)
- [Getting new Lobste.rs feed with Python and Telegram](https://blog.athulcyriac.xyz/blog/lobsters_feed/)
- [The 2020!](https://blog.athulcyriac.xyz/blog/2020/)
<!-- BLOG-POST-LIST:END -->

-------

📊 **Weekly development breakdown**
<!--START_SECTION:waka-->
```text
Go         3 hrs 51 mins   ██████████████████▓░░░░░░   74.12 % 
Markdown   35 mins         ██▓░░░░░░░░░░░░░░░░░░░░░░   11.33 % 
CSS        15 mins         █▒░░░░░░░░░░░░░░░░░░░░░░░   04.92 % 
HTML       14 mins         █▒░░░░░░░░░░░░░░░░░░░░░░░   04.69 % 
Python     14 mins         █░░░░░░░░░░░░░░░░░░░░░░░░   04.59 % 
```
<!--END_SECTION:waka-->

-------
